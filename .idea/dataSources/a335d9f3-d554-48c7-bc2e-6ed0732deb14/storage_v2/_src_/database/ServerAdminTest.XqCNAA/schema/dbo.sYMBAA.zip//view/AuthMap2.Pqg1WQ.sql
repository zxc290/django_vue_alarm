CREATE VIEW dbo.AuthMap2
AS
SELECT     dbo.URAPGF.UID, dbo.URAPGF.AID, dbo.AP_View.PID, dbo.URAPGF.FID, dbo.AP_View.PName, dbo.[function].functionDescription AS FName, dbo.URAPGF.SID, 
                      dbo.URAPGF.CID, dbo.AP_View.GName
FROM         dbo.URAPGF INNER JOIN
                      dbo.AP_View ON dbo.URAPGF.AID = dbo.AP_View.GID LEFT OUTER JOIN
                      dbo.[function] ON dbo.URAPGF.FID = dbo.[function].functionId
WHERE     (dbo.URAPGF.PID = 0) AND (dbo.AP_View.PID <> 0) AND (dbo.URAPGF.UID > 0)
go

