CREATE VIEW [dbo].[s1_UserPPsP]
	AS
	SELECT   dbo.s1_P_authority.UID, dbo.s1_P_authority.ProjId, dbo.ProjectView.ProjectName, dbo.s1_P_authority.PlatId, 
					dbo.ProjectView.PlatformName, dbo.s1_P_authority.subPlatId, dbo.ProjectView.subPlatformName
	FROM      dbo.s1_P_authority INNER JOIN
					dbo.ProjectView ON dbo.s1_P_authority.ProjId = dbo.ProjectView.ProjectId AND 
					dbo.s1_P_authority.PlatId = dbo.ProjectView.PlatformId AND 
					dbo.s1_P_authority.subPlatId = dbo.ProjectView.subPlatformId
go

