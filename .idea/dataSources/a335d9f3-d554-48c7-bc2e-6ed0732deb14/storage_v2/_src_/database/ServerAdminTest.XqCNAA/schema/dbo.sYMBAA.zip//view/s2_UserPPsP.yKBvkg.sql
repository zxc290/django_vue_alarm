CREATE VIEW [dbo].[s2_UserPPsP]
	AS
	SELECT   dbo.s2_P_authority.UID, dbo.s2_P_authority.ProjId, dbo.ProjectView.ProjectName, dbo.s2_P_authority.PlatId, 
					dbo.ProjectView.PlatformName, dbo.s2_P_authority.subPlatId, dbo.ProjectView.subPlatformName
	FROM      dbo.s2_P_authority INNER JOIN
					dbo.ProjectView ON dbo.s2_P_authority.ProjId = dbo.ProjectView.ProjectId AND 
					dbo.s2_P_authority.PlatId = dbo.ProjectView.PlatformId AND 
					dbo.s2_P_authority.subPlatId = dbo.ProjectView.subPlatformId
go

