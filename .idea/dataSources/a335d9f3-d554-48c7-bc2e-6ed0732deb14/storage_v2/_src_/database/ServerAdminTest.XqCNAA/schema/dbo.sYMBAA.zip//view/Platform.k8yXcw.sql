CREATE VIEW dbo.Platform
AS
SELECT     idx, GID, PID, PName, CreateDate, OnlineDate, OfflineDate, Company
FROM         OPENDATASOURCE ('SQLOLEDB', 'Data Source=.;User ID=DB_rwAccount!QAZ;Password=DB_dhJ15*edqdI' ).ServerManagement.dbo.App_Platform_cfg AS derivedtbl_1
go

