CREATE PROCEDURE [dbo].[dataView_Auth]
    @userid int,@systemid int,@type int
AS
BEGIN
	SET NOCOUNT ON;

declare @sql nvarchar(max)
declare @cur_AID int,@cur_PID int,@cur_FID int
create table #tmpAuth(
uid nvarchar(50),
AID int,
PID int,
FID  int,
AppName nvarchar(50),
PName nvarchar(50),
FName nvarchar(50)
)
create table #tmpOutput(
uid nvarchar(50),
AID int,
PID int,
FID  int,
AppName nvarchar(50),
PName nvarchar(50),
FName nvarchar(50)
)
create table #menu(
id  int,
name nvarchar(50),
m nvarchar(50),
c nvarchar(50),
a nvarchar(50),
parentid int,
parentName nvarchar(50),
listOrder int,
chOrder int
)

begin
 set @sql='insert into #tmpAuth select uid,AID,PID,FID,AppName,PName,FName from [ServerAdmin].dbo.NAuth ('+ cast(@userid as nvarchar) +','+ cast(@systemid as nvarchar) +') where AID!=0'
end
exec sp_executesql @sql

begin
 set @sql='insert into #tmpOutput(uid,AID,PID,FID,AppName,PName,FName) select uid,AID,PID,FID,AppName,PName,FName from [ServerAdmin].dbo.NAuth ('+cast(@userid as nvarchar) +','+ cast(@systemid as nvarchar) +') where AID=0'
end
exec sp_executesql @sql

declare AuthInclude_cursor cursor for select AID,PID,FID from #tmpAuth 
open AuthInclude_cursor
fetch next from AuthInclude_cursor into @cur_AID,@cur_PID,@cur_FID
while @@FETCH_STATUS=0
begin
	if(@cur_AID!=0) 
	begin
	   merge into #tmpOutput as m
		using (
		select uid,AID,PID,FID,AppName,PName,FName from #tmpAuth	
		) as r
		on r.FID =m.FID AND m.AID=0
		WHEN NOT MATCHED
		THEN INSERT(uid,AID,PID,FID,AppName,PName,FName)
		values(r.uid,r.AID,r.PID,r.FID,r.AppName,r.PName,FName);
    end 
	fetch next from AuthInclude_cursor into  @cur_AID,@cur_PID,@cur_FID
	
end
close AuthInclude_cursor  --关闭游标
deallocate AuthInclude_cursor   --释放游标

if(@type=0)
begin
    insert into #menu select [me].[id],[me].[name],[me].[m],[me].[c],[me].[a],[me].[parentid],mm.name as parentName,case when me.parentid = 0 THEN me.listOrder ELSE mm.listOrder END as listOrder,me.listOrder as chOrder
	FROM [ServerAdmin].[dbo].[MVCmenu] me 
	left join   [ServerAdmin].[dbo].[MVCmenu] [mm] ON [me].[parentid]=[mm].[id] 
	where [me].name in(select distinct fname from #tmpOutput ) and  [me].[display] = 0
	
	--select id,name,m,c,a,[parentid],parentName,listOrder,chOrder from #menu 
	SELECT DISTINCT FName,AID ,id,m,c,a,[parentid],parentName,listOrder,chOrder from #tmpOutput t,#menu m
	where t.FName=m.name
	group by AID,FName,id,m,c,a,[parentid],parentName,listOrder,chOrder
	order by listOrder,chOrder
end

if(@type=1)
begin
select distinct * from #tmpOutput WHERE PID>=0 order by pid,aid
end

--select distinct * from #tmpOutput


END


go

