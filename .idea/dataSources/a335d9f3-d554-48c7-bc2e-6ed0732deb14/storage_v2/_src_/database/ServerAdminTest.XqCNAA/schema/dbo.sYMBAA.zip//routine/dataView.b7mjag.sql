CREATE PROCEDURE [dbo].[dataView]
    @userid int,@systemid int,@type int
AS
BEGIN
	SET NOCOUNT ON;

declare @sql nvarchar(max)
declare @cur_AID int,@cur_PID int,@cur_FID int
create table #tmpAuth(
uid nvarchar(50),
AID int,
PID int,
CID int,
FID  int,
GName nvarchar(50),
PName nvarchar(50),
FName nvarchar(50)
)
create table #tmpOutput(
uid nvarchar(50),
AID int,
PID int,
CID int,
FID  int,
GName nvarchar(50),
PName nvarchar(50),
FName nvarchar(50)
)
create table #menu(

id  int,
name nvarchar(50),
functionId  int,
m nvarchar(50),
c nvarchar(50),
a nvarchar(50),
parentid int,
parentName nvarchar(50),
listOrder int,
chOrder int
)

begin
 set @sql='insert into #tmpAuth select uid,AID,PID,CID,FID,GName,PName,FName from [ServerAdmin].dbo.NAuth ('+ cast(@userid as nvarchar) +','+ cast(@systemid as nvarchar) +') '
end
exec sp_executesql @sql
if(@type=0)
begin
  insert into #menu select [me].[id],[me].[name],[me].functionId,[me].[m],[me].[c],[me].[a],[me].[parentid],mm.name as parentName,case when me.parentid = 0 THEN me.listOrder ELSE mm.listOrder END as listOrder,me.listOrder as chOrder
	FROM [ServerAdmin].[dbo].[MVCmenu] me 
	left join   [ServerAdmin].[dbo].[MVCmenu] [mm] ON [me].[parentid]=[mm].[id] 
	where [me].functionId in( select distinct FID from #tmpAuth ) and  [me].[display] = 0
	--select * from #menu 
	--select id,name,m,c,a,[parentid],parentName,listOrder,chOrder from #menu 
	SELECT DISTINCT FID ,FName,AID ,m.id,m,c,a,[parentid],parentName,listOrder,chOrder from #tmpAuth t,#menu m
	where t.FID=m.functionId
    group by AID,FID,FName,name,id,m,c,a,[parentid],parentName,listOrder,chOrder
	order by listOrder,chOrder 
	END
	if(@type=1)
begin
	SELECT distinct AID,PID FROM #tmpAuth WHERE PID>=0
END
if(@type=2)
begin

	SELECT distinct AID,PID,CID FROM URAPGF WHERE CID>=0 and PID=-1 and UID=@userid and SID=@systemid
END
END


go

