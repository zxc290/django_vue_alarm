CREATE VIEW dbo.ProjectView_dataview
AS
SELECT   Proj.ProjectId, Proj.ProjectName, chan.ChannelId, chan.ChannelName, chan.PlatformId, plat.PlatformName, apk.apkId, 
                apk.apkName
FROM      OPENDATASOURCE ('SQLOLEDB', 
                'Data Source=.;User ID=DB_rwAccount!QAZ;Password=DB_dhJ15*edqdI' ).ServerManagement.dbo.Project AS Proj INNER
                 JOIN
                OPENDATASOURCE ('SQLOLEDB', 
                'Data Source=.;User ID=DB_rwAccount!QAZ;Password=DB_dhJ15*edqdI' ).ServerManagement.dbo.Channel AS chan ON 
                Proj.ProjectId = chan.ProjectId LEFT OUTER JOIN
                OPENDATASOURCE ('SQLOLEDB', 
                'Data Source=.;User ID=DB_rwAccount!QAZ;Password=DB_dhJ15*edqdI' ).ServerManagement.dbo.Platform AS plat ON 
                chan.ProjectId = plat.ProjectId AND chan.PlatformId = plat.PlatformId LEFT OUTER JOIN
                OPENDATASOURCE ('SQLOLEDB', 
                'Data Source=.;User ID=DB_rwAccount!QAZ;Password=DB_dhJ15*edqdI' ).ServerManagement.dbo.apk AS apk ON 
                apk.parentProjectId = Proj.ProjectId AND apk.parentChannelId = chan.ChannelId
go

