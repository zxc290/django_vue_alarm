CREATE PROCEDURE [dbo].[Auth]
	@userid int,@systemid int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	declare @sql nvarchar(max)

	set @sql='select * from s'+cast( @systemid as nvarchar)+'_UserFunctionView where userid='+cast(@userid as nvarchar(10))+
		'union
		select * from s'+cast( @systemid as nvarchar)+'_UserGroupView where userid='+cast(@userid as nvarchar(10))

	exec sp_executesql @sql
END
go

