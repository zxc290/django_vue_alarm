CREATE VIEW dbo.App
AS
SELECT     GID, GName, GType, CreateDate, TestDate, OnlineDate, OfflineDate, Supervisor
FROM         OPENDATASOURCE ('SQLOLEDB', 'Data Source=.;User ID=DB_rwAccount!QAZ;Password=DB_dhJ15*edqdI' ).ServerManagement.dbo.App_list AS derivedtbl_1
go

