CREATE VIEW dbo.AppAuthMap
AS
SELECT   dbo.URAPGF.UID, dbo.URAPGF.AID, dbo.URAPGF.PID, dbo.URAPGF.FID, dbo.AP_View.AppName, dbo.AP_View.PName, 
                dbo.[function].functionDescription AS FName
FROM      dbo.URAPGF LEFT OUTER JOIN
                dbo.AP_View ON dbo.URAPGF.AID = dbo.AP_View.AppID AND dbo.URAPGF.PID = dbo.AP_View.PID LEFT OUTER JOIN
                dbo.[function] ON dbo.URAPGF.FID = dbo.[function].functionId
go

