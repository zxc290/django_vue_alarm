CREATE VIEW dbo.UserAuth
AS
SELECT DISTINCT dbo.URGF.idx, dbo.URGF.UID, dbo.URGF.FID, [function].functionDescription, dbo.URGF.SID
FROM      dbo.[function] AS [function] INNER JOIN
                dbo.URGF ON [function].functionId = dbo.URGF.FID AND [function].systemId = dbo.URGF.SID
go

