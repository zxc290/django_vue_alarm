CREATE VIEW [dbo].[s1_UserFunctionView]
	AS
	SELECT   dbo.[User].userId, dbo.[User].userIdentity, dbo.[User].passWord, dbo.[User].emailAddress, dbo.[User].phoneNumber, 
					dbo.[User].ipAddress, dbo.[User].userName, dbo.[User].admin, dbo.s1_A_authority.GID, '' AS groupName, 
					dbo.s1_A_authority.FID, dbo.[function].functionDescription
	FROM      dbo.[User] INNER JOIN
					dbo.s1_A_authority ON dbo.[User].userId = dbo.s1_A_authority.UID INNER JOIN
					dbo.[function] ON dbo.s1_A_authority.FID = dbo.[function].functionId
go

