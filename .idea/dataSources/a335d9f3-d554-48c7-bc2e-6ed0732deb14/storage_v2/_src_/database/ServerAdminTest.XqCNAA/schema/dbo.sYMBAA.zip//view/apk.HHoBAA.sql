CREATE VIEW dbo.apk
AS
SELECT   idx, apkId, apkName, parentChannelId, parentProjectId
FROM      OPENDATASOURCE ('SQLOLEDB', 
                'Data Source=.;User ID=DB_rwAccount!QAZ;Password=DB_dhJ15*edqdI' ).ServerManagement.dbo.apk AS derivedtbl_1
go

