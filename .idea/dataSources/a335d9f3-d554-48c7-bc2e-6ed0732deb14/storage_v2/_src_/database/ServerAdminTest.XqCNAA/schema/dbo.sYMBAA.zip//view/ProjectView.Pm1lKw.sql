CREATE VIEW dbo.ProjectView
AS
SELECT     Proj.ProjectId, Proj.ProjectName, Plat.PlatformId, Plat.PlatformName, Plat.idx
FROM         OPENDATASOURCE ('SQLOLEDB', 'Data Source=.;User ID=DB_rwAccount!QAZ;Password=DB_dhJ15*edqdI' ).ServerManagement.dbo.Project AS Proj INNER JOIN
                      OPENDATASOURCE ('SQLOLEDB', 'Data Source=.;User ID=DB_rwAccount!QAZ;Password=DB_dhJ15*edqdI' ).ServerManagement.dbo.Platform AS Plat ON 
                      Proj.ProjectId = Plat.ProjectId AND Proj.ProjectId = Plat.ProjectId
go

