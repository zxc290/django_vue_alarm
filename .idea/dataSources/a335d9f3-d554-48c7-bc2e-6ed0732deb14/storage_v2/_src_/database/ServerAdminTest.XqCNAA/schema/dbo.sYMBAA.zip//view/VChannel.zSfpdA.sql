CREATE VIEW dbo.VChannel
AS
SELECT   derivedtbl_1.*
FROM      OPENDATASOURCE ('SQLOLEDB', 
                'Data Source=.;User ID=DB_rwAccount!QAZ;Password=DB_dhJ15*edqdI' ).ServerManagement.dbo.App_Channel_list AS derivedtbl_1
go

