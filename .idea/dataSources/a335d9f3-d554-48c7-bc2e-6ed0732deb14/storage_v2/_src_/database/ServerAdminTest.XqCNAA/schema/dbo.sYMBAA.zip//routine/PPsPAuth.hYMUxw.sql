
CREATE PROCEDURE [dbo].[PPsPAuth] 
	@uid int,@sysid int,@projId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;   	
declare @sql nvarchar(max)
declare @cur_projId int,@cur_platId int,@cur_type int
CREATE TABLE #tmpAuth(
[idx] [int] IDENTITY(1,1) NOT NULL,
[UID] [int] NULL,
[ProjId] [int] NULL,
[PlatId] [int] NULL,
[type] [int] NULL
) ON [PRIMARY]

create table #tmpOutput(
ProjectId int,
ProjectName nvarchar(50),
PlatformId int,
PlatformName nvarchar(50),
type int
)
if(@projId=0)
begin
set @sql='insert into #tmpAuth select UID, ProjId, PlatId, type
 from s'+cast(@sysid as nvarchar)+'_P_authority where [UID]='+cast(@uid as nvarchar)
 end
 else
 begin
 set @sql='insert into #tmpAuth select UID, ProjId, PlatId, type
 from s'+cast(@sysid as nvarchar)+'_P_authority where [UID]='+cast(@uid as nvarchar)+' and ProjId='+cast(@projId as nvarchar)
 end
exec sp_executesql @sql
--取出所有项目权限
--查询包含权限
declare AuthInclude_cursor cursor for select ProjId, PlatId,type from #tmpAuth --where type>0
open AuthInclude_cursor
fetch next from AuthInclude_cursor into @cur_projId,@cur_platId,@cur_type
while @@FETCH_STATUS=0
begin
	if(@cur_projId=0)--所有项目
	begin
		insert into #tmpOutput select *,@cur_type from ProjectView
	end
	else
	begin
		if(@cur_platId=0)--项目下所有平台
		begin
		insert into #tmpOutput select *,@cur_type from ProjectView where ProjectId=@cur_projId
		end
		else if(@cur_platId<0)
		begin
			insert into #tmpOutput select [ProjectId],[ProjectName],@cur_platId,'',@cur_platId,'',@cur_type from ProjectView where ProjectId=@cur_projId
		end		
	end

	fetch next from AuthInclude_cursor into @cur_projId,@cur_platId,@cur_type
end
close AuthInclude_cursor  --关闭游标
deallocate AuthInclude_cursor   --释放游标

select distinct * from #tmpOutput

drop table #tmpOutput
drop table #tmpAuth
END
go

