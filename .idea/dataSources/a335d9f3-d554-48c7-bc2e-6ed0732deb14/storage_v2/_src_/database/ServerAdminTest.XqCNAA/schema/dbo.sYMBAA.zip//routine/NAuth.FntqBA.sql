-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[NAuth]
(	
	-- Add the parameters for the function here
	@uid int,@sys int
)
RETURNS TABLE 
AS
RETURN 
(
	-- Add the SELECT statement with parameter references here
	SELECT [UID]
      ,[AID]
      ,[CID]
      ,[PID]
      ,[FID]
      ,[GName]
      ,[PName]
      ,[FName] from dbo.AuthMap where [UID]=@uid and [SID]=@sys
	  union
	SELECT [UID]
      ,[AID]
      ,[CID]
      ,[PID]
      ,[FID]
      ,[GName]
      ,[PName]
      ,[FName] from dbo.AuthMap2 where [UID]=@uid and [SID]=@sys
)


go

