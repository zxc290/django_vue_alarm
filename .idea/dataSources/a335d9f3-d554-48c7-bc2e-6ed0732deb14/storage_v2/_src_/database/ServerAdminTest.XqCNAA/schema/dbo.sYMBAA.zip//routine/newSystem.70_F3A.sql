-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[newSystem] 
	@sysid int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    declare @sql nvarchar(max)

	set @sql='CREATE TABLE [dbo].[s'+CAST(@sysid as nvarchar)+'_A_authority](
		[idx] [int] IDENTITY(1,1) NOT NULL,
		[UID] [int] NULL,
		[GID] [int] NULL,
		[FID] [int] NULL
	) ON [PRIMARY]'
	exec sp_executesql @sql
	print '创建权限关系表......完成'
	set @sql='CREATE TABLE [dbo].[s'+CAST(@sysid as nvarchar)+'_P_authority](
		[idx] [int] IDENTITY(1,1) NOT NULL,
		[UID] [int] NULL,
		[ProjId] [int] NULL,
		[PlatId] [int] NULL,
		[subPlatId] [int] NULL,
		[type] [int] NULL
	) ON [PRIMARY]'
	exec sp_executesql @sql
	print '创建项目关系表......完成'
	-------创建视图UserFunctionView
	set @sql='CREATE VIEW [dbo].[s'+CAST(@sysid as nvarchar)+'_UserFunctionView]
	AS
	SELECT   dbo.[User].userId, dbo.[User].userIdentity, dbo.[User].passWord, dbo.[User].emailAddress, dbo.[User].phoneNumber, 
					dbo.[User].ipAddress, dbo.[User].userName, dbo.[User].admin, dbo.s'+CAST(@sysid as nvarchar)+'_A_authority.GID, '''' AS groupName, 
					dbo.s'+CAST(@sysid as nvarchar)+'_A_authority.FID, dbo.[function].functionDescription
	FROM      dbo.[User] INNER JOIN
					dbo.s'+CAST(@sysid as nvarchar)+'_A_authority ON dbo.[User].userId = dbo.s'+CAST(@sysid as nvarchar)+'_A_authority.UID INNER JOIN
					dbo.[function] ON dbo.s'+CAST(@sysid as nvarchar)+'_A_authority.FID = dbo.[function].functionId'
	exec sp_executesql @sql
	print '创建视图UserFunctionView'
	-------创建视图UserGroupView
	set @sql='CREATE VIEW [dbo].[s'+CAST(@sysid as nvarchar)+'_UserGroupView]
	AS
	SELECT   dbo.[User].userId, dbo.[User].userIdentity, dbo.[User].passWord, dbo.[User].emailAddress, dbo.[User].phoneNumber, 
					dbo.[User].ipAddress, dbo.[User].userName, dbo.[User].admin, dbo.VGroupToVFunction.groupId, 
					dbo.VGroupToVFunction.groupName, dbo.VGroupToVFunction.functionId, 
					dbo.VGroupToVFunction.functionDescription
	FROM      dbo.[User] INNER JOIN
					dbo.s'+CAST(@sysid as nvarchar)+'_A_authority ON dbo.[User].userId = dbo.s'+CAST(@sysid as nvarchar)+'_A_authority.UID INNER JOIN
					dbo.VGroupToVFunction ON dbo.s'+CAST(@sysid as nvarchar)+'_A_authority.GID = dbo.VGroupToVFunction.groupId'
	exec sp_executesql @sql
	print '创建视图UserGroupView'
	-------创建视图UserPPsP
	set @sql='CREATE VIEW [dbo].[s'+CAST(@sysid as nvarchar)+'_UserPPsP]
	AS
	SELECT   dbo.s'+CAST(@sysid as nvarchar)+'_P_authority.UID, dbo.s'+CAST(@sysid as nvarchar)+'_P_authority.ProjId, dbo.ProjectView.ProjectName, dbo.s'+CAST(@sysid as nvarchar)+'_P_authority.PlatId, 
					dbo.ProjectView.PlatformName, dbo.s'+CAST(@sysid as nvarchar)+'_P_authority.subPlatId, dbo.ProjectView.subPlatformName
	FROM      dbo.s'+CAST(@sysid as nvarchar)+'_P_authority INNER JOIN
					dbo.ProjectView ON dbo.s'+CAST(@sysid as nvarchar)+'_P_authority.ProjId = dbo.ProjectView.ProjectId AND 
					dbo.s'+CAST(@sysid as nvarchar)+'_P_authority.PlatId = dbo.ProjectView.PlatformId AND 
					dbo.s'+CAST(@sysid as nvarchar)+'_P_authority.subPlatId = dbo.ProjectView.subPlatformId'
	exec sp_executesql @sql
	print '创建视图UserPPsP'
END
go

