CREATE VIEW dbo.AC_View
AS
SELECT   dbo.App.AppID, dbo.App.AppName, dbo.VChannel.CID, dbo.VChannel.CName
FROM      dbo.App INNER JOIN
                dbo.VChannel ON dbo.App.AppID = dbo.VChannel.GID
go

