CREATE VIEW [dbo].[VGroupToVFunction]
AS
SELECT   dbo.[group].groupId, dbo.[group].groupName, dbo.[function].functionId, dbo.[function].functionDescription, 
                dbo.[group].systemId
FROM      dbo.g2f INNER JOIN
                dbo.[group] ON dbo.g2f.GroupId = dbo.[group].groupId INNER JOIN
                dbo.[function] ON dbo.g2f.FunctionId = dbo.[function].functionId
go

