CREATE VIEW dbo.Channel
AS
SELECT     ChannelId, ChannelName, ProjectId, PlatformId
FROM         OPENDATASOURCE ('SQLOLEDB', 'Data Source=.;User ID=DB_rwAccount!QAZ;Password=DB_dhJ15*edqdI' ).ServerManagement.dbo.Channel AS derivedtbl_1
go

