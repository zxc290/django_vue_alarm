CREATE VIEW dbo.AuthMap
AS
SELECT     dbo.URAPGF.UID, dbo.URAPGF.AID, dbo.URAPGF.PID, dbo.URAPGF.FID, dbo.AP_View.PName, dbo.[function].functionDescription AS FName, dbo.URAPGF.SID, 
                      dbo.URAPGF.CID, dbo.AP_View.GName
FROM         dbo.URAPGF LEFT OUTER JOIN
                      dbo.AP_View ON dbo.URAPGF.PID = dbo.AP_View.PID AND dbo.URAPGF.AID = dbo.AP_View.GID LEFT OUTER JOIN
                      dbo.[function] ON dbo.URAPGF.FID = dbo.[function].functionId
go

