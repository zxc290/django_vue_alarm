CREATE VIEW dbo.UserApp
AS
SELECT   dbo.URAP.UID, dbo.AP_View.AppID, dbo.AP_View.AppName, dbo.AP_View.PID, dbo.AP_View.PName, 
                dbo.URAP.SID
FROM      dbo.URAP INNER JOIN
                dbo.AP_View ON dbo.URAP.AID = dbo.AP_View.AppID AND dbo.URAP.PID = dbo.AP_View.PID
go

