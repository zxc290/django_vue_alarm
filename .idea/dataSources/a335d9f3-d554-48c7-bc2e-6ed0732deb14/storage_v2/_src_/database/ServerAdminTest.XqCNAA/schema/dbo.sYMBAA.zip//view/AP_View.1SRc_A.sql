CREATE VIEW dbo.AP_View
AS
SELECT     dbo.Platform.PID, dbo.Platform.PName, dbo.Platform.idx, dbo.App.GID, dbo.App.GName
FROM         dbo.App INNER JOIN
                      dbo.Platform ON dbo.App.GID = dbo.Platform.GID
go

