CREATE FUNCTION [dbo].[ProcessSvrType_des]
(
	@svrtype int
)
RETURNS nvarchar(50)
AS
BEGIN
declare @newtypeid nvarchar(50)
set @newtypeid='1'
if(@svrtype&2>0)
	set @newtypeid=@newtypeid+',3'
if(@svrtype&16>0)
	set @newtypeid=@newtypeid+',7'
if(@svrtype&32>0)
	set @newtypeid=@newtypeid+',8'
if(@svrtype&64>0)
	set @newtypeid=@newtypeid+',6'
if(@svrtype&128>0)
	set @newtypeid=@newtypeid+',9'
return @newtypeid
END


go

