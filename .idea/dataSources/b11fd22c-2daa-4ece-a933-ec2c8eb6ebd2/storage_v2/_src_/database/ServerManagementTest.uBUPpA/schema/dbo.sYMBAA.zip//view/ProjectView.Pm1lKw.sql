CREATE VIEW dbo.ProjectView
AS
SELECT   dbo.Project.ProjectId, dbo.Project.ProjectName, dbo.Platform.PlatformId, dbo.Platform.PlatformName, 
                dbo.Platform.idx
FROM      dbo.Project INNER JOIN
                dbo.Platform ON dbo.Project.ProjectId = dbo.Platform.ProjectId
go

