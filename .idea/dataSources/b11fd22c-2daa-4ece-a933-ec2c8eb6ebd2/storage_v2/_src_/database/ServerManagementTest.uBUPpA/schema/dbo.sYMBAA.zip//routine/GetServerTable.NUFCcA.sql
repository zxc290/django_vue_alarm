-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[GetServerTable]
(	
	@gid int,@cid int 
)

RETURNS @temp_table  TABLE 
(
	id int,
    GID       int ,
	CID       int  ,  
	PID       int  ,  
	zonename  nvarchar(50),
	statu      int,
	server_statu   int , 
	server_suggest int, 
	is_delete  int, 
	zoneidx int ,	
	SID   int,
	SName  nvarchar(50),
	DevID  int,
	VID  int,
	OpenDate date ,
	MergeDate date ,
	MergeID int ,
	MergeIdx int,
	ServerID int,
	CT_ipadd  nvarchar(50),
	domain nvarchar(50),
	appid nvarchar(50),
	LoginPort nvarchar(50)
	
	)

  AS
BEGIN 
    declare @pid int
	select @pid=pid  FROM [ServerManagement].[dbo].[App_Channel_list] where CID=@cid;
	    

		   with svrlist1 as
		   (
			select a.*,case when (DN is null or DN='') then CT_ipadd else DN end as CT_ipadd from 
			(SELECT id, SID, SName, PID, GID, dbo.GetMergeDev(id) AS DevID, VID,  OpenDate, MergeDate, MergeID, MergeIdx, ServerID,DN, LoginPort
			FROM APP_Server_list where APP_Server_list.GID=@gid and APP_Server_list.pid=@pid) a, server_iplist_tbl b 
			where a.DevID=b.[Dev_id])
			
			insert into @temp_table(id,cid,statu,server_statu,server_suggest,zonename,SID,SName,PID,GID,DevID,VID,OpenDate,MergeDate,MergeID,MergeIdx,ServerID,zoneidx,is_delete,appid,CT_ipadd,domain,LoginPort)
			SELECT  dbo.App_Server_Channel.id,dbo.App_Server_Channel.CID, dbo.App_Server_Channel.statu, dbo.App_Server_Channel.server_statu, dbo.App_Server_Channel.server_suggest, dbo.App_Server_Channel.zonename,
				  a.SID, a.SName,a.PID,dbo.App_Server_Channel.GID,  a.DevID, a.VID,a.OpenDate, a.MergeDate, a.MergeID, a.MergeIdx, 
				  a.ServerID,dbo.App_Server_Channel.zoneidx, dbo.App_Server_Channel.is_delete, dbo.App_Server_Channel.appid,case when (DN is null or DN='') then CT_ipadd+':'+ISNULL(a.LoginPort,'8001') else DN end as CT_ipadd,  a.DN, ISNULL(a.LoginPort,'8001') as LoginPort
				FROM dbo.App_Server_Channel INNER JOIN
								  svrlist1 a ON dbo.App_Server_Channel.zoneidx = a.id
								  where dbo.App_Server_Channel.CID=@cid and is_delete=0  and appid!=''
								  order by appid ,sid
		
		

	RETURN 
END


go

