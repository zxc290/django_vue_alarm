CREATE VIEW dbo.View_Dev
AS
SELECT   ip.Dev_id, ip.CT_ipadd, ip.Local_ipadd, ip.[delete], ip.server_on, ip.info, ip.CPU, ip.HD, ip.MEM, idc.IDC_name, 
                idc.IDC_Locate, idc.IDC_Desc, idc.IDC_id, ip.server_off
FROM      dbo.server_iplist_tbl AS ip INNER JOIN
                dbo.Dev_IDC_list AS idc ON ip.IDC_id = idc.IDC_id
go

