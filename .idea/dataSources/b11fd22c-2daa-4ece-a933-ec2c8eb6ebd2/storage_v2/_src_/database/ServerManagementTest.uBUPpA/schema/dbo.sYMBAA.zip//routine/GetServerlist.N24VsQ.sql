-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[GetServerlist]

	@gid int ,
	@cid int ,
	@appid varchar(100)=''
AS
BEGIN
 declare @pid int
 select @pid=pid  FROM [ServerManagement].[dbo].[App_Channel_list] where CID=@cid


select a.*,case when (DN is null or DN='') then CT_ipadd else DN end as CT_ipadd into #tmp from 
(SELECT id, SID, SName, PID, GID, dbo.GetMergeDev(id) AS DevID, VID,  OpenDate, MergeDate, MergeID, MergeIdx, ServerID,DN
FROM APP_Server_list where APP_Server_list.GID=@gid and APP_Server_list.pid=@pid) a, server_iplist_tbl b 
where a.DevID=b.[Dev_id]
	

 if @appid != ''
    BEGIN
		SELECT  dbo.App_Server_Channel.id,dbo.App_Server_Channel.CID, dbo.App_Server_Channel.statu, dbo.App_Server_Channel.server_statu, 
						  dbo.App_Server_Channel.server_suggest, dbo.App_Server_Channel.zonename, a.SID, a.DevID, a.OpenDate, 
						  a.MergeDate, a.MergeID, a.MergeIdx, a.ServerID, dbo.App_Server_Channel.GID, 
						  a.PID, a.SName,dbo.App_Server_Channel.zoneidx, a.VID, dbo.App_Server_Channel.is_delete, dbo.App_Server_Channel.appid, a.DN
		FROM dbo.App_Server_Channel INNER JOIN
						  #tmp a ON dbo.App_Server_Channel.zoneidx = a.id
						  where dbo.App_Server_Channel.CID=@cid and is_delete=0  and appid=@appid
						  order by appid ,sid
		
	 end
	 else
	 	SELECT  dbo.App_Server_Channel.id,dbo.App_Server_Channel.CID, dbo.App_Server_Channel.statu, dbo.App_Server_Channel.server_statu, 
						  dbo.App_Server_Channel.server_suggest, dbo.App_Server_Channel.zonename, a.SID, a.DevID, a.OpenDate, 
						  a.MergeDate, a.MergeID, a.MergeIdx, a.ServerID, dbo.App_Server_Channel.GID, 
						  a.PID, a.SName,dbo.App_Server_Channel.zoneidx, a.VID, dbo.App_Server_Channel.is_delete, dbo.App_Server_Channel.appid, a.DN
		FROM dbo.App_Server_Channel INNER JOIN
						  #tmp a ON dbo.App_Server_Channel.zoneidx = a.id
						  where dbo.App_Server_Channel.CID=@cid and is_delete=0  and appid!=''
						  order by appid ,sid
	RETURN 
			
         
END


go

