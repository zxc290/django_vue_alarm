CREATE VIEW dbo.V_Ipcurrentused
AS
SELECT     ip, [status], [owner], [up], [down], gametypeno, gametype, zonename, hequ
FROM         (SELECT     row_number() OVER (partition BY iplst.ct_ipadd
                       ORDER BY CASE WHEN hequ = '0' THEN '9999-12-31' ELSE hequ END DESC, zoneid DESC, kaiqu_time DESC) AS id, iplst.ct_ipadd AS ip, iplst.[delete] AS [status], 
                      iplst.owner_id AS [owner], iplst.server_on AS [up], server_off AS [down], svrlst.gametypeno, svrlst.gametype, svrlst.zonename, hequ, svrlst.ServermanagerPort
FROM         server_iplist_tbl iplst LEFT JOIN
                      Server_table svrlst ON iplst.ct_ipadd = svrlst.ipadd) a
WHERE     id = 1 AND [status] = 0 AND ServermanagerPort <> 0
go

