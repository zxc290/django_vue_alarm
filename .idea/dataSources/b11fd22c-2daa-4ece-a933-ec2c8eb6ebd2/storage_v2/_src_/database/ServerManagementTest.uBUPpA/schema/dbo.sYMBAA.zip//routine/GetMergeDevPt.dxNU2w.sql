-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION  [dbo].[GetMergeDevPt]
(	
		@zoneid int,@game int, @pt int
)
RETURNS int
AS
BEGIN
declare @devid int,@hequid int
    select  @hequid=[hequid],@devid=[Dev_id] from [dbo].[Server_table] where zoneid=@zoneid and gametypeno=@game and ptid=@pt
    
	while(@hequid>0)
	begin	  
		set @zoneid=@hequid
	    select  @hequid=[hequid],@devid=[Dev_id] from [dbo].[Server_table] where zoneid=@zoneid and gametypeno=@game and ptid=@pt
	
	end
	return @devid
END
go

