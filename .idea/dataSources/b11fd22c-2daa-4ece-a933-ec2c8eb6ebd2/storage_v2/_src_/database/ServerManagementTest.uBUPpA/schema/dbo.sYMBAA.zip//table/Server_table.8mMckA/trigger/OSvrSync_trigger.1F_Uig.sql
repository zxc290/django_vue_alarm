CREATE TRIGGER [dbo].[OSvrSync_trigger]
on [dbo].[Server_table]
instead of insert
as begin
if object_id(N'tempdb..#Server_table_tmp') is not null
drop table #Server_table_tmp
select * into #Server_table_tmp from inserted
--select *from #Server_table_tmp
if exists(select * from inserted where [trigger_flag]='' or [trigger_flag] is null)
begin

	declare @querryidA int,@querryidB int,@gid int
	select @querryidA=b.idx from inserted a,App_Query_Cfg b
	where a.LogUid_in=b.QueryUser and a.LogPwd_in=b.QueryPass
	select @querryidB=b.idx from inserted a,App_Query_Cfg b
	where a.LogUid_out=b.QueryUser and a.LogPwd_out=b.QueryPass
	select @gid=gametypeno from inserted
	if(@gid in (48,50,51,55,56)) begin
		insert into dbo.APP_Server_list 
		([SID],[SName], [PID],[GID],     [APID],[DevID],[Type],                     [Status],[ProStatus],[OpenDate],                     [MergeDate],[MergeID],        [MergeIdx],[ServerID],[GSList],[DBSvr_in],[DBName_in],[DBQueryId_in],[DBSvr_out],[DBName_out],[DBQueryId_out],[ServerPath],[SMPort],           [LoginPort],[RmbPort],[db_svrcfg],[db_player],[db_login],[db_super],[db_rmb],[db_param],[trigger_flag]) 
		select 
		zoneid,zonename,ptid, GameTypeno,0,     Dev_id, dbo.ProcessSvrType(SvrType),Lock,    prostat,    isnull(kaiqu_time,'1970-01-01'),'1970-01-01',isnull(hequid,0),0,         LogZoneId, SvrId,   LogSvrIp_in,LogDB_in,  @querryidA,    logsvrip_out,logdb_out,   @querryidB,    [ServerPath],[ServermanagerPort],[LoginPort],[RmbPort],[db_svrcfg],[db_player],[db_login],[db_super],[db_rmb],[db_param] ,'old_trigger' as [trigger_flag]  from inserted
	end
end
else
update #Server_table_tmp set [trigger_flag]=''
insert [dbo].[Server_table]
([ZoneName],[ZoneId],[Ptid],[PtName],[SvrId],[SvrType],[GameTypeno],[GameType],[IpAdd],[Dev_id],[DomainName],[H&S_info],[ServermanagerPort],[Lock],[prostat],[LogZoneId],[LogSvrIp_in],[LogDB_in],[LogUid_in],[LogPwd_in],[LogSvrIp_out],[LogDB_out],[LogUid_out],[LogPwd_out],[HeQu],[kaiqu_time],[hequid],[hequidx],[ServerPath],[LoginPort],[RmbPort],[db_svrcfg],[db_player],[db_login],[db_super],[db_rmb],[db_param],[trigger_flag]) 
select 
 [ZoneName],[ZoneId],[Ptid],[PtName],[SvrId],[SvrType],[GameTypeno],[GameType],[IpAdd],[Dev_id],[DomainName],[H&S_info],[ServermanagerPort],[Lock],[prostat],[LogZoneId],[LogSvrIp_in],[LogDB_in],[LogUid_in],[LogPwd_in],[LogSvrIp_out],[LogDB_out],[LogUid_out],[LogPwd_out],[HeQu],[kaiqu_time],[hequid],[hequidx],[ServerPath],[LoginPort],[RmbPort],[db_svrcfg],[db_player],[db_login],[db_super],[db_rmb],[db_param],[trigger_flag] from #Server_table_tmp
	  end
go

