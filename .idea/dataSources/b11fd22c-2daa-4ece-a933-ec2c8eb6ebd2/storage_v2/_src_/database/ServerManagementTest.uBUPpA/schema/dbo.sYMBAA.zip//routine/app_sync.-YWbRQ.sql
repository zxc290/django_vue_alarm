-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[app_sync]

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	 with  aa as( SELECT [Ptid],[PtName],[GameTypeno],min([kaiqu_time]) as onlinetime
  FROM [ServerManagement].[dbo].[Server_table]
  where zoneid>0 and zoneid<9000 and HeQu='0'
  group by [Ptid] ,[PtName] ,[GameTypeno]) 
 merge into [App_Platform_cfg] as a
 using aa as b
 on a.gid=b.gametypeno and a.pid=b.[Ptid]
 when not matched then insert values(gametypeno,[Ptid],[PtName],null,onlinetime,null,null);
END
go

