-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[dev_used]
(	
	-- Add the parameters for the function here
	@date date ='1970-01-01'
)
RETURNS TABLE 
AS
RETURN 
(

with used as (
SELECT [gametypeno], case when idcid in (2,3) then 100  when idcid in (6,7) then 200  else idcid end  as idcid	,sum([used]) as used
FROM .[dbo].[devused]
WHERE logdate = case when @date ='1970-01-01' then cast(getdate() as date) else @date end
GROUP by [gametypeno],
  case when idcid in (2,3) then 100
  when idcid in (6,7) then 200
  else idcid end
  )
SELECT  gametypeno,isnull(sum([4]),0) '江苏腾奕' ,isnull(sum([100]),0)'hanfei',isnull(sum([200]),0) 'Tencent'
FROM used as SourceTable  PIVOT( SUM(used) FOR idcid in ( [4],[100],[200],[5] )) AS T 
group by gametypeno

)
go

