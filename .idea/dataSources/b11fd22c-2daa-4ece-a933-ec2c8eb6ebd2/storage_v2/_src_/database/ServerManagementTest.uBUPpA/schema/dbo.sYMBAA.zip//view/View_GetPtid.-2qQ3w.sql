CREATE VIEW dbo.View_GetPtid
AS
SELECT     dbo.App_Channel_list.CID, dbo.App_Channel_list.CName, dbo.App_Channel_list.PID, AppidManagement.dbo.app_manage.GameTypeno, 
                      AppidManagement.dbo.app_manage.Appid, AppidManagement.dbo.app_manage.ChannelId, AppidManagement.dbo.app_manage.Appname, 
                      AppidManagement.dbo.app_manage.GameType
FROM         dbo.App_Channel_list INNER JOIN
                      AppidManagement.dbo.app_manage ON dbo.App_Channel_list.GID = AppidManagement.dbo.app_manage.GameTypeno AND 
                      dbo.App_Channel_list.CID = AppidManagement.dbo.app_manage.ChannelId
go

