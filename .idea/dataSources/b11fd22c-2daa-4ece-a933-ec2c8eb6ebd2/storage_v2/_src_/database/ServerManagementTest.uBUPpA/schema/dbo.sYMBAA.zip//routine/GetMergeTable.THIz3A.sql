-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[GetMergeTable]
(	
	@gid int,@pid int,@cid int 
)

RETURNS @temp_table  TABLE 
(
	id int,
    GID       int ,
	CID       int  ,  
	PID       int  ,  
	zonename  nvarchar(50),
	statu      int,
	server_statu   int , 
	server_suggest int, 
	is_delete  int, 
	zoneidx int ,	
	SID   int,
	SName  nvarchar(50),
	DevID  int,
	VID  int,
	OpenDate date ,
	MergeDate date ,
	MergeID int ,
	MergeIdx int,
	ServerID int,
	CT_ipadd  nvarchar(50),
	domain nvarchar(50),
	appid nvarchar(50)
	)

  AS
BEGIN 
	 with svrlist1 as
    (SELECT  dbo.App_Server_Channel.id,dbo.App_Server_Channel.CID, dbo.App_Server_Channel.statu, dbo.App_Server_Channel.server_statu, 
                      dbo.App_Server_Channel.server_suggest, dbo.App_Server_Channel.zonename, dbo.APP_Server_list.SID, dbo.APP_Server_list.DevID, dbo.APP_Server_list.OpenDate, 
                      dbo.APP_Server_list.MergeDate, dbo.APP_Server_list.MergeID, dbo.APP_Server_list.MergeIdx, dbo.APP_Server_list.ServerID, dbo.App_Server_Channel.GID, 
                      dbo.APP_Server_list.PID, dbo.APP_Server_list.SName,dbo.App_Server_Channel.zoneidx, dbo.APP_Server_list.VID, dbo.App_Server_Channel.is_delete, dbo.App_Server_Channel.appid, dbo.APP_Server_list.DN
	FROM dbo.App_Server_Channel INNER JOIN
                      dbo.APP_Server_list ON dbo.App_Server_Channel.zoneidx = dbo.APP_Server_list.id
                      where dbo.App_Server_Channel.CID=@cid and dbo.App_Server_Channel.GID=@gid and is_delete=0  )
                      
	insert into @temp_table(id,cid,statu,server_statu,server_suggest,zonename,SID,SName,PID,GID,DevID,VID,OpenDate,MergeDate,MergeID,MergeIdx,ServerID,zoneidx,is_delete,appid,domain,CT_ipadd)
	select a.*,case when (DN is null or DN='') then CT_ipadd else DN end as CT_ipadd from (SELECT id, CID,statu,server_statu,server_suggest,zonename, SID, SName, PID, GID, dbo.GetMergeDev(zoneidx) AS DevID, VID,  OpenDate, MergeDate, MergeID, MergeIdx, ServerID, zoneidx,is_delete,appid,DN
	FROM svrlist1) a,server_iplist_tbl b where a.DevID=b.[Dev_id]
	
	
	RETURN 
END


go

