CREATE trigger [dbo].[NSvrUPdate_trigger]
on [dbo].[APP_Server_list]
instead of UPDATE
as
begin
--declare @zid int,@zname nvarchar(50),@pid int,@gid int
--,@loguid_in nvarchar(50),@logpwd_in nvarchar(50),@logqid_in int
--,@loguid_out nvarchar(50),@logpwd_out nvarchar(50),@logqid_out int,
--@ptname nvarchar(50),@gamename nvarchar(50),@ipadd nvarchar(50)

	if exists(select * from inserted where trigger_flag='' or trigger_flag is null)
	begin
	--print 'APP_Server_list'
	--select MergeDate from inserted
	--select @logqid_in=DBQueryId_in,@logqid_out=DBQueryId_out from inserted	
	--select @loguid_in=QueryUser,@logpwd_in=QueryPass from App_Query_Cfg where idx=@logqid_in
	--select @loguid_out=QueryUser,@logpwd_out=QueryPass from App_Query_Cfg where idx=@logqid_out	
	--select @gamename=a.GName,@gid=a.GID from App_list a,inserted b where a.GID=b.GID
	--select @ptname=a.PName from App_Platform_cfg a,inserted b where a.PID=b.PID and a.GID=b.GID
	--select @ipadd=a.ct_ipadd from server_iplist_tbl a,inserted b where a.Dev_id=b.DevID
	update Server_table set 
	[ZoneName] = c.SName
      ,[ZoneId] = c.SID
      ,[Ptid] = c.PID
      ,[PtName] = dbo.search_trigger_inf(c.GID,c.PID,5)
      ,[SvrId] = c.GSList
      ,[SvrType] = dbo.ProcessSvrType_des(c.Type)
      ,[GameTypeno] = c.GID
      ,[GameType] = dbo.search_trigger_inf(c.GID,'',3)
      ,[IpAdd] = dbo.find_ip(c.DevID)
      ,[Dev_id] = c.DevID
      ,[DomainName] = dbo.find_ip(c.DevID) 
      ,[ServermanagerPort] = c.SMPort
      ,[Lock] = c.Status
      ,[prostat] = c.ProStatus
      ,[LogZoneId] = c.ServerID
      ,[LogSvrIp_in] = c.DBSvr_in
      ,[LogDB_in] = c.DBName_in
      ,[LogUid_in] = dbo.search_trigger_inf(c.DBQueryId_in,'',1)
      ,[LogPwd_in] = dbo.search_trigger_inf(c.DBQueryId_in,'',2)
      ,[LogSvrIp_out] = c.DBSvr_out
      ,[LogDB_out] = c.DBName_out
      ,[LogUid_out] =dbo.search_trigger_inf(c.DBQueryId_out,'',1)
      ,[LogPwd_out] = dbo.search_trigger_inf(c.DBQueryId_out,'',2)
      ,[HeQu] = case when c.MergeDate='1970-01-01' then CAST('0' AS nvarchar(10)) else  cast(c.MergeDate as nvarchar(20)) end
      ,[kaiqu_time] = c.OpenDate
      ,[hequid] = c.MergeID
      ,[ServerPath] = c.ServerPath
      ,[LoginPort] = c.LoginPort
      ,[RmbPort] = c.RmbPort
      ,[db_svrcfg] = c.db_svrcfg
      ,[db_player] = c.[db_player]
		,[db_login] = c.[db_login]
		,[db_super] = c.[db_super]
		,[db_rmb] = c.[db_rmb]
		,[db_param] = c.[db_param]
      ,[trigger_flag] = 'ntrigger'
	 from Server_table a,inserted c
	where a.ZoneId=c.SID and a.Ptid=c.PID and a.GameTypeno=c.GID
	end
--print 'APP_Server_list外'
	update APP_Server_list set 
	[SID] = c.[SID]
,[SName] = c.[SName]
,[PID] = c.[PID]
,[GID] = c.[GID]
,[APID] = c.[APID]
,Display=c.display
,[DevID] = c.[DevID]
,[DN] = c.[DN]
,[VID] = c.[VID]
,[Type] = c.[Type]
,[Status] = c.[Status]
,[ProStatus] = c.[ProStatus]
,[OpenDate] = c.[OpenDate]
,[MergeDate] = c.[MergeDate]
,[MergeID] = c.[MergeID]
,[MergeIdx] = c.[MergeIdx]
,[ServerID] = c.[ServerID]
,[GSList] = c.[GSList]
,[DBSvr_in] = c.[DBSvr_in]
,[DBName_in] = c.[DBName_in]
,[DBQueryId_in] = c.[DBQueryId_in]
,[DBSvr_out] = c.[DBSvr_out]
,[DBName_out] = c.[DBName_out]
,[DBQueryId_out] = c.[DBQueryId_out]
,[ServerPath] = c.[ServerPath]
,[SMPort] = c.[SMPort]
,[LoginPort] = c.[LoginPort]
,[RmbPort] = c.[RmbPort]
,[db_svrcfg] = c.[db_svrcfg]
,[db_player] = c.[db_player]
,[db_login] = c.[db_login]
,[db_super] = c.[db_super]
,[db_rmb] = c.[db_rmb]
,[db_param] = c.[db_param]
,[trigger_flag] =''
	from APP_Server_list a,inserted c
	where a.id=c.id


	
end
go

