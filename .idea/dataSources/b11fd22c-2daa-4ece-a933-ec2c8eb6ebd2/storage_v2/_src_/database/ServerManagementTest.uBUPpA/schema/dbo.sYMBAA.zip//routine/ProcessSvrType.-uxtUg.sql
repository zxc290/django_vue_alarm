
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[ProcessSvrType]
(
	@svrtype nvarchar(50)
)
RETURNS int
AS
BEGIN
declare @first int,@typeid nvarchar(10),@laststr nvarchar(50),@newtypeid int,@nexttypeid int
if(@svrtype='' or @svrtype is null)
	return 0
set @first=charindex(',',@svrtype)
if(@first>0) 
begin
set @typeid= substring(@svrtype,1,@first-1)
set @laststr=substring(@svrtype,@first+1,len(@svrtype)-@first)
end
else
begin
set @typeid=cast(@svrtype as int)
set @laststr=''
end
set @newtypeid=case 
when @typeid='1' then 2
when @typeid='3' then 2
when @typeid='6' then 64
when @typeid='7' then 16
when @typeid='8' then 32
when @typeid='9' then 128
end
if(@laststr<>'')
	set @nexttypeid= dbo.ProcessSvrType(@laststr)
else
	set @nexttypeid=0
return @newtypeid|@nexttypeid
END

go

