CREATE FUNCTION [dbo].[find_dev_id]
(
	@search_ip nvarchar(15)
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @dev_id nvarchar(15) 

	-- Add the T-SQL statements to compute the return value here
	SELECT  @dev_id =  dev_id 
	From dbo.server_iplist_tbl
	where  CT_ipadd = @search_ip
	and [delete]=0

	-- Return the result of the function
	RETURN @dev_id

END
go

