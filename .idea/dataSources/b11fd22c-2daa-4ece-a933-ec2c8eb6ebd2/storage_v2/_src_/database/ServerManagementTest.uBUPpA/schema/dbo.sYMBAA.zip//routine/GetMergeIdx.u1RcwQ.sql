-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetMergeIdx]
(
	@gameid int, @pid int ,@sid int
)
RETURNS int
AS
BEGIN
declare @idx int,@mergeid int
	select @mergeid=MergeID,@idx=id from APP_Server_list where gid=@gameid  and sid=@sid and pid=@pid
	while(@mergeid>0)
	begin
		set @sid=@mergeid
		select @mergeid=mergeid,@idx=id  from APP_Server_list where gid=@gameid  and sid=@sid and pid=@pid	
	end
	
	return @idx
END


go

