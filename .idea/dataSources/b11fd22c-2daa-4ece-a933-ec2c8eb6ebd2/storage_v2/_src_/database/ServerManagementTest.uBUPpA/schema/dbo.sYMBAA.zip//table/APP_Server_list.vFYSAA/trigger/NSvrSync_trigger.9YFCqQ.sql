-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[NSvrSync_trigger]
   ON  [dbo].[APP_Server_list]
   instead of insert
AS 
BEGIN
if object_id(N'tempdb..#ntmp') is not null
drop table #ntmp
select * into #ntmp from inserted
--select *from #ntmp
--为避免重复触发
if exists(select * from inserted where [trigger_flag]='' or [trigger_flag] is null)
begin
--若此字段有值，则表示由程序自动操作插入，非人为操作，无需要再进行同步插入
	

		insert into Server_table 
		([ZoneName],[ZoneId],[Ptid],[PtName],  [SvrId],  [SvrType],                       [GameTypeno],[GameType],[IpAdd],    [Dev_id],[DomainName],[H&S_info],[ServermanagerPort],[Lock],     [prostat],     [LogZoneId],[LogSvrIp_in],   [LogDB_in],   [LogUid_in],              [LogPwd_in],               [LogSvrIp_out], [LogDB_out],    [LogUid_out],              [LogPwd_out],                [HeQu],         [kaiqu_time],[hequid],     [ServerPath],   [LoginPort],   [RmbPort],  [db_svrcfg],[db_player],[db_login],[db_super],[db_rmb],[db_param],[trigger_flag]) 
		SELECT     
		svr.SName,   svr.SID,svr.PID, pt.PName,svr.GSList,dbo.ProcessSvrType_des(svr.Type),svr.GID,     app.GName,ip.CT_ipadd,svr.DevID,ip.CT_ipadd,'',        svr.SMPort,         svr.Status, svr.ProStatus, svr.ServerID, svr.DBSvr_in, svr.DBName_in, q_in.QueryUser AS user_in, q_in.QueryPass AS pass_in, svr.DBSvr_out, svr.DBName_out, q_out.QueryUser AS user_out,q_out.QueryPass AS pass_out,svr.MergeDate, svr.OpenDate,  svr.MergeID, svr.ServerPath, svr.LoginPort, svr.RmbPort, svr.db_svrcfg,svr.db_player,svr.db_login,svr.db_super,svr.db_rmb,svr.db_param,'new_trigger'  as [trigger_flag]            
	     FROM         dbo.App_Query_Cfg AS q_out RIGHT OUTER JOIN
                      inserted AS svr INNER JOIN
                      dbo.App_Platform_cfg AS pt INNER JOIN
                      dbo.App_list AS app ON pt.GID = app.GID ON svr.GID = app.GID AND svr.PID = pt.PID LEFT OUTER JOIN
                      dbo.server_iplist_tbl AS ip ON svr.DevID = ip.Dev_id LEFT OUTER JOIN
                      dbo.App_Query_Cfg AS q_in ON svr.DBQueryId_in = q_in.idx ON q_out.idx = svr.DBQueryId_out
end
else
update #ntmp set [trigger_flag]=''
insert [dbo].APP_Server_list
([SID],[SName],[PID],[GID],[APID],[Display],[DevID],[DN],[VID],[Type],[Status],[ProStatus],[OpenDate],[MergeDate],[MergeID],[MergeIdx],[ServerID],[GSList],[DBSvr_in],[DBName_in],[DBQueryId_in],[DBSvr_out],[DBName_out],[DBQueryId_out],[ServerPath],[SMPort],[LoginPort],[RmbPort],[db_svrcfg],[db_player],[db_login],[db_super],[db_rmb],[db_param],[trigger_flag]) 
select 
 [SID],[SName],[PID],[GID],[APID],[Display],[DevID],[DN],[VID],[Type],[Status],[ProStatus],[OpenDate],[MergeDate],[MergeID],[MergeIdx],[ServerID],[GSList],[DBSvr_in],[DBName_in],[DBQueryId_in],[DBSvr_out],[DBName_out],[DBQueryId_out],[ServerPath],[SMPort],[LoginPort],[RmbPort],[db_svrcfg],[db_player],[db_login],[db_super],[db_rmb],[db_param],[trigger_flag] from #ntmp

END
go

