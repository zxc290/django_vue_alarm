CREATE VIEW dbo.V_Svrlogurl
AS
SELECT     ZoneName AS svrname, ZoneId AS svrid, Ptid AS ptid, GameTypeno AS proid, LogSvrIp_in AS loginip, LogDB_in AS logindb, LogUid_in AS loginuid, 
                      LogPwd_in AS loginpw, LogSvrIp_out AS logotip, HeQu AS hequtime, kaiqu_time AS opentime, Lock AS svrstatus
FROM         dbo.Server_table
WHERE     (Ptid > 0) AND (GameTypeno BETWEEN 10 AND 97) AND (LogSvrIp_in IS NOT NULL) AND (Lock = 0) AND (kaiqu_time IS NOT NULL) AND (LogDB_in > N'0') AND 
                      (LogUid_in > N'0') AND (LogPwd_in > N'0') AND (kaiqu_time > N'1970-01-01')
go

