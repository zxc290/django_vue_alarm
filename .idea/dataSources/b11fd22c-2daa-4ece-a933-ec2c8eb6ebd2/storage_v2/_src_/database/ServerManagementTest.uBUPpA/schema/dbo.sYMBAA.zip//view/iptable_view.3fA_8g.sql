CREATE VIEW dbo.iptable_view
AS
SELECT     dbo.iptable_group_rule.idx, dbo.iptable_rules.id AS ruleid, dbo.iptable_group_rule.groupid, dbo.iptable_rules.IP, dbo.iptable_rules.protocol, dbo.iptable_rules.port, 
                      dbo.iptable_rules.des, dbo.iptable_rules.filterlist, dbo.iptable_filter.filterlistname, dbo.iptable_filter.action, dbo.iptable_rules.direction, dbo.iptable_rules.info
FROM         dbo.iptable_filter INNER JOIN
                      dbo.iptable_rules ON dbo.iptable_filter.iptabletype = dbo.iptable_rules.filterlist INNER JOIN
                      dbo.iptable_group_rule ON dbo.iptable_rules.id = dbo.iptable_group_rule.ruleid
go

