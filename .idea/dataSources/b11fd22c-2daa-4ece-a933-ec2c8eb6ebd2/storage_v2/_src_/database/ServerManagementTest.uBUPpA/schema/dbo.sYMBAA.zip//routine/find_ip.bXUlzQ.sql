create FUNCTION [dbo].[find_ip]
(
	@dev_id int
)
RETURNS nvarchar(15)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @search_ip nvarchar(15) 

	-- Add the T-SQL statements to compute the return value here
	SELECT  @search_ip =  [CT_ipadd] 
	From dbo.server_iplist_tbl
	where  [Dev_id] = @dev_id
	and [delete]=0

	-- Return the result of the function
	RETURN @search_ip

END
go

