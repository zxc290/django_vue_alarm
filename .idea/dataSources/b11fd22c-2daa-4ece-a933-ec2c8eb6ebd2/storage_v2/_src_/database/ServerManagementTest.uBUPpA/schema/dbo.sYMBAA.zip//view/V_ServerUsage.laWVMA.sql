CREATE VIEW dbo.V_ServerUsage
AS
SELECT     iplst.CT_ipadd AS ip, iplst.[delete], iplst.owner_id, iplst.server_on, iplst.server_off, svrlst.GameTypeno, svrlst.GameType, svrlst.ZoneName, svrlst.HeQu, svrlst.Lock, 
                      svrlst.kaiqu_time
FROM         dbo.Server_table AS svrlst INNER JOIN
                      dbo.server_iplist_tbl AS iplst ON svrlst.IpAdd = iplst.CT_ipadd
go

