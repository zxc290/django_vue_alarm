CREATE VIEW dbo.VAPP_Server_list
AS
SELECT     id, SID, SName, PID, GID, APID, dbo.GetMergeDev(id) AS DevID, VID, Type, Status, ProStatus, OpenDate, MergeDate, MergeID, MergeIdx, ServerID, GSList, DBSvr_in, 
                      DBName_in, DBQueryId_in, DBSvr_out, DBName_out, DBQueryId_out
FROM         dbo.APP_Server_list
go

