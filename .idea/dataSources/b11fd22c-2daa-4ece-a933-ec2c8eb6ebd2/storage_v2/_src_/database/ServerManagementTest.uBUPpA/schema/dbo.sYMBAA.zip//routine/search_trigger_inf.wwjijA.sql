create FUNCTION [dbo].[search_trigger_inf]
(
	@parameter1 varchar(50),
	@parameter2 varchar(50)='',
	@get_type int =0				--0:get_idx   1：get_QueryUser  2:get_QueryPass 3:get_GName  4:get_GID  5:get_PName
)
RETURNS nvarchar(50)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @RETURN VARCHAR(50)
	-- Add the T-SQL statements to compute the return value here

		if @get_type = 0
		select @RETURN=idx from App_Query_Cfg where QueryUser=@parameter1 and QueryPass=@parameter2
		
		else if @get_type = 1	
			select @RETURN=QueryUser from App_Query_Cfg where idx=@parameter1
		
		else if @get_type = 2	
			select @RETURN=QueryPass from App_Query_Cfg where idx=@parameter1
			
		else if @get_type = 3	
			select @RETURN=GName from App_list where GID=@parameter1
			
		else if @get_type = 4	
			select @RETURN=GID from App_list where GID=@parameter1
								
		else if @get_type = 5	
			select @RETURN=PName from App_Platform_cfg  where GID=@parameter1 and PID=@parameter2		

	-- Return the result of the function
	return @RETURN

END
go

