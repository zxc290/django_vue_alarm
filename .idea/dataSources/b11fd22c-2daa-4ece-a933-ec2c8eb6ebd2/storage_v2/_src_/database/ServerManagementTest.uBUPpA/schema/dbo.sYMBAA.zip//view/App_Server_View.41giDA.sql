CREATE VIEW dbo.App_Server_View
AS
SELECT     ap.PName, asl.SID, asl.SName, dev.CT_ipadd AS DevIP, asl.Type, asl.Status, asl.ProStatus, asl.OpenDate, asl.MergeDate, asl.MergeID, asl.ServerID, asl.GSList, 
                      asl.DBSvr_in, asl.DBName_in, qin.QueryUser AS UserIn, qin.QueryPass AS PassIn, asl.DBName_out, asl.DBSvr_out, qout.QueryUser AS UserOut, 
                      qout.QueryPass AS PassOut, ap.PID, asl.DevID, asl.APID, asl.VID, asl.id, app.GID, app.GName, asl.LocatinPath, asl.SMPort
FROM         dbo.App_Platform_cfg AS ap INNER JOIN
                      dbo.APP_Server_list AS asl ON ap.PID = asl.PID AND ap.GID = asl.GID INNER JOIN
                      dbo.server_iplist_tbl AS dev ON asl.DevID = dev.Dev_id INNER JOIN
                      dbo.App_list AS app ON ap.GID = app.GID INNER JOIN
                      dbo.App_Query_Cfg AS qin ON asl.DBQueryId_in = qin.idx INNER JOIN
                      dbo.App_Query_Cfg AS qout ON asl.DBQueryId_out = qout.idx
go

