CREATE VIEW dbo.View_IPSec
AS
SELECT     a.devID AS Dev_id, a.devIP AS CT_ipadd, a.proID, b.IPSec_group
FROM         dbo.V_DevUsed AS a LEFT OUTER JOIN
                      dbo.server_iplist_tbl AS b ON a.devIP = b.CT_ipadd
WHERE     (a.idcID <> 1) AND (b.[delete] = 0)
go

