CREATE trigger [dbo].[OSvrUPdate_trigger]
on [dbo].[Server_table]
instead of UPDATE
as
begin
--declare @zid int,@zname nvarchar(50),@pid int,@gid int
--,@loguid_in nvarchar(50),@logpwd_in nvarchar(50),@logqid_in int
--,@loguid_out nvarchar(50),@logpwd_out nvarchar(50),@logqid_out int
--select *from inserted
	
	--select @loguid_in=[LogUid_in],@logpwd_in=[LogPwd_in],@loguid_out=[LogUid_out],@logpwd_out=[LogPwd_out] from inserted
	--select @logqid_in=idx from App_Query_Cfg where QueryUser=@loguid_in and QueryPass=@logpwd_in
	--select @logqid_out=idx from App_Query_Cfg where QueryUser=@loguid_out and QueryPass=@logpwd_out
	if exists(select * from inserted where trigger_flag='' or trigger_flag is null)
	begin
	--print 'Server_table'
	update APP_Server_list set 
	SID=c.ZoneId,
	SName=c.ZoneName,
	PID=c.ptid,
	GID=c.GameTypeno,
	APID=0,
	DevID=c.Dev_id,
	[Type]=dbo.ProcessSvrType(c.SvrType),
	[Status]=c.Lock,
	ProStatus=c.prostat,
	OpenDate=isnull(c.kaiqu_time,'1970-01-01'),
	[MergeDate]=case when c.HeQu='' then '1970-01-01' when C.HeQu='0' then '1970-01-01' when C.HeQu='1970-01-01' then '0' else c.HeQu end,
	MergeID=ISNULL( c.hequid,0),
	MergeIdx=case when c.hequid=0 then 0 else  dbo.GetMergeIdx(c.GameTypeno,c.ptid,c.ZoneId) end,
	ServerID=c.LogZoneId,
	GSList=c.SvrId,
	DBSvr_in=c.LogSvrIp_in,
	DBName_in=c.LogDB_in,
	DBQueryId_in=dbo.search_trigger_inf(c.LogUid_in,c.LogPwd_in,0),
	DBSvr_out=c.LogSvrIp_out,
	DBName_out=c.LogDB_out,
	DBQueryId_out=dbo.search_trigger_inf(c.LogUid_out,c.LogPwd_out,0),
	ServerPath=c.ServerPath,
	SMPort=c.ServermanagerPort,
	LoginPort=c.LoginPort,
	RmbPort=c.RmbPort,
	db_svrcfg=c.db_svrcfg,
	[db_player] = c.[db_player]
	,[db_login] = c.[db_login]
	,[db_super] = c.[db_super]
	,[db_rmb] = c.[db_rmb]
	,[db_param] = c.[db_param]
	,trigger_flag='otrigger'
	from APP_Server_list a,inserted c
	where a.SID=c.ZoneId and a.PID=c.Ptid and a.GID=c.GameTypeno

	end
	--print 'Server_table外'
	--select HeQu from inserted
	update Server_table set 
	[ZoneName] = c.ZoneName
      ,[ZoneId] = c.ZoneId
      ,[Ptid] = c.Ptid
      ,[PtName] = c.PtName
      ,[SvrId] = c.SvrId
      ,[SvrType] = c.SvrType
      ,[GameTypeno] = c.GameTypeno
      ,[GameType] = c.GameType
      ,[IpAdd] = c.IpAdd
      ,[Dev_id] = c.Dev_id
      ,[DomainName] = c.DomainName
      ,[H&S_info] = c.[H&S_info]
      ,[ServermanagerPort] = c.ServermanagerPort
      ,[Lock] = c.Lock
      ,[prostat] = c.prostat
      ,[LogZoneId] = c.LogZoneId
      ,[LogSvrIp_in] = c.LogSvrIp_in
      ,[LogDB_in] = c.LogDB_in
      ,[LogUid_in] = c.LogUid_in
      ,[LogPwd_in] = c.LogPwd_in
      ,[LogSvrIp_out] = c.LogSvrIp_out
      ,[LogDB_out] = c.LogDB_out
      ,[LogUid_out] = c.LogUid_out
      ,[LogPwd_out] = c.LogPwd_out
      ,[HeQu] =C.HeQu
      ,[kaiqu_time] = c.kaiqu_time
      ,[hequid] = c.hequid
      ,[hequidx] = c.hequidx
      ,[ServerPath] = c.ServerPath
      ,[LoginPort] = c.LoginPort
      ,[RmbPort] = c.RmbPort
      ,[db_svrcfg] = c.db_svrcfg
      ,[db_player] = c.[db_player]
	  ,[db_login] = c.[db_login]
	  ,[db_super] = c.[db_super]
	  ,[db_rmb] = c.[db_rmb]
	  ,[db_param] = c.[db_param]
      ,[trigger_flag] = ''
	 from Server_table a,inserted c
	where a.idx=c.idx
end
go

