CREATE VIEW dbo.View_ServerInfo
AS
SELECT     svr.id, svr.SID, svr.SName, svr.PID, svr.DevID, ip.CT_ipadd, svr.Type, svr.Status, svr.ProStatus, svr.MergeID, svr.OpenDate, svr.MergeDate, svr.ServerID, 
                      svr.GSList, svr.DBSvr_in, svr.DBName_in, q_in.QueryUser AS user_in, q_in.QueryPass AS pass_in, svr.DBSvr_out, svr.DBName_out, q_out.QueryUser AS user_out, 
                      q_out.QueryPass AS pass_out, pt.PName, app.GID, app.GName, svr.ServerPath, svr.SMPort, svr.LoginPort, svr.RmbPort, svr.db_svrcfg, svr.Display, svr.DN, 
                      svr.db_player, svr.db_login, svr.db_super, svr.db_rmb, svr.db_param
FROM         dbo.App_Query_Cfg AS q_out RIGHT OUTER JOIN
                      dbo.APP_Server_list AS svr INNER JOIN
                      dbo.App_Platform_cfg AS pt INNER JOIN
                      dbo.App_list AS app ON pt.GID = app.GID ON svr.GID = app.GID AND svr.PID = pt.PID LEFT OUTER JOIN
                      dbo.server_iplist_tbl AS ip ON svr.DevID = ip.Dev_id LEFT OUTER JOIN
                      dbo.App_Query_Cfg AS q_in ON svr.DBQueryId_in = q_in.idx ON q_out.idx = svr.DBQueryId_out
go

