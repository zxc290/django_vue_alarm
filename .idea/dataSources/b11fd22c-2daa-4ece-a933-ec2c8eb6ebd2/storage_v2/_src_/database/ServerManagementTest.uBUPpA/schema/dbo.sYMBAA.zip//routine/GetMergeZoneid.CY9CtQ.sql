-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION  [dbo].[GetMergeZoneid]
(	
		@game int, @pt int,@zoneid int
)
RETURNS int
AS
BEGIN
declare  @hequid int, @sid int
    select  @hequid=[hequid],@sid= zoneid from [dbo].[Server_table] where zoneid=@zoneid and gametypeno=@game and ptid=@pt
    
	while(@hequid>0)
	begin	  
		set @zoneid=@hequid
	    select  @hequid=[hequid] ,@sid= zoneid from [dbo].[Server_table] where zoneid=@zoneid and gametypeno=@game and ptid=@pt
	
	end
	return @sid
END
go

