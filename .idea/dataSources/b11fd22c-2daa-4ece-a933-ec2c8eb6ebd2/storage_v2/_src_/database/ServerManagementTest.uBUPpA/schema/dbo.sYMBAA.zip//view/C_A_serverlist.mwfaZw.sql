CREATE VIEW dbo.C_A_serverlist
AS
SELECT     dbo.App_Channel_list.CID, dbo.App_Server_Channel.zonename, dbo.App_Server_Channel.server_statu, dbo.App_Server_Channel.server_suggest, 
                      dbo.App_Server_Channel.is_delete, dbo.App_Server_Channel.zoneidx, dbo.APP_Server_list.id, dbo.APP_Server_list.SID, dbo.APP_Server_list.SName, 
                      dbo.APP_Server_list.PID, dbo.APP_Server_list.GID, dbo.APP_Server_list.APID, dbo.GetMergeDev(dbo.APP_Server_list.id) AS NewDev, dbo.APP_Server_list.VID, 
                      dbo.APP_Server_list.Type, dbo.APP_Server_list.Status, dbo.APP_Server_list.ProStatus, dbo.APP_Server_list.OpenDate, dbo.APP_Server_list.MergeDate, 
                      dbo.APP_Server_list.MergeID, dbo.APP_Server_list.MergeIdx, dbo.APP_Server_list.ServerID, dbo.APP_Server_list.GSList, dbo.APP_Server_list.DBSvr_in, 
                      dbo.APP_Server_list.DBName_in, dbo.APP_Server_list.DBQueryId_in, dbo.APP_Server_list.DBSvr_out, dbo.APP_Server_list.DBName_out, 
                      dbo.APP_Server_list.DBQueryId_out, dbo.server_iplist_tbl.CT_ipadd
FROM         dbo.APP_Server_list INNER JOIN
                      dbo.server_iplist_tbl ON dbo.APP_Server_list.DevID = dbo.server_iplist_tbl.Dev_id INNER JOIN
                      dbo.App_Server_Channel ON dbo.APP_Server_list.id = dbo.App_Server_Channel.zoneidx AND dbo.APP_Server_list.GID = dbo.App_Server_Channel.GID INNER JOIN
                      dbo.App_Channel_list ON dbo.App_Server_Channel.CID = dbo.App_Channel_list.CID AND dbo.App_Server_Channel.GID = dbo.App_Channel_list.GID
go

