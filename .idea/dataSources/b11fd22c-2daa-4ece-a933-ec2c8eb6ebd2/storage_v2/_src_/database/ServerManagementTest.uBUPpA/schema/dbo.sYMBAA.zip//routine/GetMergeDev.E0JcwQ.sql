-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetMergeDev]
(
	@idx int
)
RETURNS int
AS
BEGIN
declare @devid int,@mergeidx int
	select @mergeidx=mergeidx,@devid=DevID from APP_Server_list where id=@idx	
	while(@mergeidx>0)
	begin
		set @idx=@mergeidx
		select @mergeidx=mergeidx,@devid=DevID from APP_Server_list where id=@idx		
	end
	return @devid
END
go

