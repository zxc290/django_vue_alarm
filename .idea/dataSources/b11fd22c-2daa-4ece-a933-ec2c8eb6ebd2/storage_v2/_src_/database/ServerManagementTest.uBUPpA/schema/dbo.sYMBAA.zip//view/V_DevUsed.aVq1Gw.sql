

CREATE view [dbo].[V_DevUsed] 
as 
select iplst.dev_id as devID,ct_ipadd as devIP ,iplst.idc_id as idcID,
	(select zonename+',' from Server_table
		where dev_id = iplst.dev_id
		and hequ='0'
		FOR XML PATH('')) as areaName,
	(select cast(idx as nvarchar)+',' from Server_table
		where dev_id = iplst.dev_id
		and hequ='0'
		FOR XML PATH('')) as areaID,
	(select distinct (cast(gametypeno as nvarchar)+',') from Server_table
		where dev_id = iplst.dev_id
		and hequ='0'
		FOR XML PATH('')) as proID
from server_iplist_tbl iplst
where iplst.[delete]=0

go

