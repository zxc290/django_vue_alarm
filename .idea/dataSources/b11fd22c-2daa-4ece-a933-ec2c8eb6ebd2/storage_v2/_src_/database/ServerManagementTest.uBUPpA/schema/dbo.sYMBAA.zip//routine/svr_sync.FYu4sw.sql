-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[svr_sync ]

	@gameid int

AS
BEGIN
	with m as
(select 
zoneid,zonename,ptid,GameTypeno,0 as apid,s.Dev_id,SvrType,Lock,prostat,
case when kaiqu_time='0' then '1970-01-01' else kaiqu_time end as kaiqu_time,
case when HeQu='0' then '1970-01-01' else hequ end as hequ,
hequid,LogZoneId,SvrId,LogSvrIp_in,LogDB_in,aqf1.idx as idxin,logsvrip_out,logdb_out,aqf2.idx as idxout ,[ServerPath]
      ,[LoginPort]
      ,[RmbPort]
      ,[db_svrcfg]
      ,[trigger_flag]
from Server_table s left join server_iplist_tbl d on s.dev_id=d.dev_id left join App_Query_Cfg aqf1
on s.LogUid_in=aqf1.QueryUser and s.logpwd_in=aqf1.[QueryPass] left join App_Query_Cfg aqf2
on s.LogUid_out=aqf2.QueryUser and s.logpwd_out=aqf2.[QueryPass]
where s.gametypeno=@gameid and d.[delete]=0
)

merge into APP_Server_list a
using m
on a.sid=m.zoneid and a.pid=m.ptid and a.gid=m.gametypeno 
when matched then
UPDATE  SET  [SName]=m.zonename,[OpenDate]=m.kaiqu_time,[DevID]=m.Dev_id,[MergeDate]=m.hequ,[MergeID]=m.hequid,[DBSvr_out]=m.logsvrip_out,[DBSvr_in]=m.LogSvrIp_in
when not matched then
insert ([SID],[SName],[PID],[GID],[APID],[DevID],[Type],[Status],[ProStatus],[OpenDate],[MergeDate],[MergeID],[ServerID],[GSList]
,[DBSvr_in],[DBName_in],[DBQueryId_in],[DBSvr_out],[DBName_out],[DBQueryId_out],[ServerPath]
      ,[LoginPort]
      ,[RmbPort]
      ,[db_svrcfg]
      ,[trigger_flag]) 
values (zoneid,zonename,ptid,GameTypeno,apid,Dev_id,0,Lock,prostat,kaiqu_time,hequ,hequid,LogZoneId,SvrId,LogSvrIp_in,LogDB_in,idxin,logsvrip_out,logdb_out,idxout,[ServerPath]
      ,[LoginPort]
      ,[RmbPort]
      ,[db_svrcfg]
      ,'PROCEDURE');


with b as
	 (  select * FROM [ServerManagement].[dbo].[APP_Server_list] where gid=@gameid and [MergeId]>0)
merge into APP_Server_list a
using b
on a.sid=b.sid and a.pid=b.pid and a.gid=b.gid
when matched then
UPDATE  SET [MergeIdx]=dbo.GetMergeIdx(a.gid,a.pid,a.sid) ;

END

go

