-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE Update_Server_table
AS
BEGIN
	
	SET NOCOUNT ON;
	print 2;
END
go

