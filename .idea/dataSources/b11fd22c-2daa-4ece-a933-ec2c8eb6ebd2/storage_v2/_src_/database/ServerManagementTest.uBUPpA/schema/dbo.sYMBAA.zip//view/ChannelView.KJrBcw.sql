CREATE VIEW dbo.ChannelView
AS
SELECT   dbo.Project.ProjectId, dbo.Project.ProjectName, dbo.Channel.ChannelId, dbo.Channel.ChannelName, 
                dbo.subPlatform.subPlatformId, dbo.subPlatform.subPlatformName, dbo.subPlatform.idx
FROM      dbo.Channel INNER JOIN
                dbo.Project ON dbo.Channel.ProjectId = dbo.Project.ProjectId INNER JOIN
                dbo.subPlatform ON dbo.Channel.ProjectId = dbo.subPlatform.parentProjectId AND 
                dbo.Channel.ChannelId = dbo.subPlatform.parentChannelId
go

