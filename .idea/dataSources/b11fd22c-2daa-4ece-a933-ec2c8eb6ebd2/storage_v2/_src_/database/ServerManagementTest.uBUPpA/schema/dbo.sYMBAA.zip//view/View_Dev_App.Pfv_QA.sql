CREATE VIEW dbo.View_Dev_App
AS
SELECT   dbo.View_Dev.Dev_id, dbo.View_Dev.CT_ipadd, dbo.View_Dev.Local_ipadd, dbo.View_Dev.[delete], 
                dbo.View_Dev.server_on, dbo.View_Dev.info, dbo.View_Dev.CPU, dbo.View_Dev.HD, dbo.View_Dev.IDC_name, 
                dbo.View_Dev.IDC_Locate, dbo.View_Dev.IDC_Desc, dbo.View_Dev.MEM, svrtab.GameTypeno, svrtab.GameType
FROM      dbo.View_Dev LEFT OUTER JOIN
                    (SELECT   idx, ZoneName, ZoneId, Ptid, PtName, SvrId, SvrType, GameTypeno, GameType, IpAdd, Dev_id, 
                                     DomainName, [H&S_info], ServermanagerPort, Lock, prostat, LogZoneId, LogSvrIp_in, LogDB_in, 
                                     LogUid_in, LogPwd_in, LogSvrIp_out, LogDB_out, LogUid_out, LogPwd_out, HeQu, kaiqu_time, 
                                     hequid
                     FROM      dbo.Server_table
                     WHERE   (HeQu = '0')) AS svrtab ON dbo.View_Dev.Dev_id = svrtab.Dev_id
go

